//
//  ViewController.m
//  quanquan
//
//  Created by yangxiaoteng on 16/4/8.
//  Copyright © 2016年 yxteng. All rights reserved.
//

#import "ViewController.h"
#import "RingView.h"

@interface ViewController ()
{
//    NSTimer *_timer;
//    UIView *_ringView;
    RingView *_ringView;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _ringView = [[RingView alloc] initWithPoint:(CGPointMake(0, 0)) andRadius:50];
    _ringView.center = self.view.center;
    //_ringView. = CGPointMake(100, 200);
    _ringView.firstAlpha = 0.1;
    [self.view addSubview:_ringView];
    [_ringView start];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
