//
//  RingView.m
//  quanquan
//
//  Created by yangxiaoteng on 16/4/8.
//  Copyright © 2016年 yxteng. All rights reserved.
//

#import "RingView.h"
#import "NSTimer+EOCBlocksSupport.h"

@interface RingView()
{
    NSTimer *_timer;
    BOOL _isStarted;
}
@end

@implementation RingView

-(instancetype)initWithPoint:(CGPoint)point andRadius:(CGFloat)radius {
    if (self = [self initWithFrame:(CGRectMake(point.x, point.y, radius * 2, radius * 2))]) {
        _multiple = 3.0;
        _ringColor = [UIColor redColor];
        _firstAlpha = 1.0;
        _lastAlpha = 0;
        
        _longTime = 4.0;
        _radius = radius;
        _intervalTime = 1.0;
        _animationOption = UIViewAnimationOptionCurveEaseOut;
    }
    
    return self;
}


-(void)start {
    _isStarted = YES;
    __weak RingView *weakSelf = self;
    _timer = [NSTimer eoc_scheduledTimerWithTimeInterval:_intervalTime block:^{
        [weakSelf action];
    } repeats:YES];
    [[NSRunLoop currentRunLoop] addTimer:_timer forMode:NSRunLoopCommonModes];
}

-(void)stop {
    _isStarted = NO;
    if (_timer != nil) {
        [_timer invalidate];
        _timer = nil;
    }
    for (UIView *ringView in self.subviews) {
        [ringView removeFromSuperview];
    }
}

-(BOOL)status {
    return _isStarted;
}

-(void)action{
    UIView *ringView = [[UIView alloc]initWithFrame:(CGRectMake(0, 0, _radius * 2, _radius * 2))];
    ringView.backgroundColor = _ringColor;
    ringView.alpha = _firstAlpha;
    ringView.layer.cornerRadius = _radius;
    
    [self addSubview:ringView];
    
    [UIView animateWithDuration:_longTime delay:0 options:(_animationOption) animations:^{
        ringView.transform = CGAffineTransformMakeScale(_multiple,_multiple);
        ringView.alpha = _lastAlpha;
    } completion:^(BOOL finished) {
        [ringView removeFromSuperview];
    }];
}

-(void)dealloc {
    NSLog(@"RingView   dealloc");
}

@end








