//
//  RingView.h
//  quanquan
//
//  Created by yangxiaoteng on 16/4/8.
//  Copyright © 2016年 yxteng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RingView : UIView

@property(nonatomic, assign)CGFloat multiple;               //扩大的倍数 默认3
@property(nonatomic, strong)UIColor *ringColor;                 //颜色 默认红色
@property(nonatomic, assign)CGFloat firstAlpha;             //初始时透明度 默认1
@property(nonatomic, assign)CGFloat lastAlpha;              //最后时透明度 默认0
@property(nonatomic, assign)NSTimeInterval longTime;         //默认3秒
@property(nonatomic, assign)NSTimeInterval intervalTime;     //默认间隔时间1秒
@property(nonatomic, assign)CGFloat radius;                 //半径
@property(nonatomic, assign)UIViewAnimationOptions animationOption; //默认UIViewAnimationOptionCurveEaseOut


-(instancetype)initWithPoint:(CGPoint)point andRadius:(CGFloat)radius;
-(void)start;
-(void)stop;
-(BOOL)status;

@end








