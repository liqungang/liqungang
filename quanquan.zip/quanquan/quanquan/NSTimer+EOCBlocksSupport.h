//
//  NSTimer+EOCBlocksSupport.h
//  diandiandian
//
//  Created by yangxiaoteng on 16/4/8.
//  Copyright © 2016年 yxteng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSTimer (EOCBlocksSupport)

+(NSTimer *)eoc_scheduledTimerWithTimeInterval:(NSTimeInterval)interval block:(void(^)())blocl repeats:(BOOL)repeats;

@end
